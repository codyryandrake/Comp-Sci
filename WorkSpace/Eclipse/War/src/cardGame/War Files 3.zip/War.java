/*
 * Name: Cody Ryan
 * Date: 10.13.18
 * Description: The War class handles playing the game of war, utilizing a Deck object.
 * Sources Cited: <Professor Case, Spencer Poole, Class Slides,
 * 								 Course Textbook: "Starting Out With Java", 
 * 								 https://www.compart.com/en/unicode/search?q=number#characters
 * 								 stackoverflow.com>
 */

package cardGame;

import java.util.Scanner; //For reading from the keyboard
import java.io.IOException; //For possible exception handling

public class War 
{
	
	static int pAPoints = 0; //Score keeper variable for Player A
	static int pBPoints = 0; //Score keeper variable for Player B
	static int round = 1; //The round always starts as one.
	static boolean enableAnimation = true; //boolean control for pause() method.
	static boolean enablePrompts = true; //boolean control for pause() method.
	static int gType; //Variable for controlling how the deck is displayed
	static boolean three = false; //third round detector.
	
	public static void main(String[] args) throws Exception
	{
		Scanner keyboard = new Scanner(System.in); //Create a new Scanner object <keyboard>
		String input; //This variable will hold user input.
		
		loadingEffect("Please choose from the following options:\n", 10);
		loadingEffect("demo \t\t[The game will run itself with animation enabled and prompts disabled.]", 20);
		loadingEffect("classic \t[Play the game with minimal animation. Prompts are still enabled.]", 10);
		loadingEffect("animated \t[Play the game with animation and prompts enabled.]", 10);
		loadingEffect("fast \t\t[The deck will be displayed, and the game will be played instantly.]\n", 10);
		loadingEffect("Please enter your selection here:", 20);
		
		input = keyboard.next();
		if ("demo".equals(input)||"d".equals(input)) { //Runs the game automatically without prompts.
			enableAnimation = true;
			enablePrompts = false;
			gType = 90; //The contents of the deck will be fully displayed
		}
		else if ("classic".equals(input)||"c".equals(input)) { //Runs the game without animation.
			enableAnimation = false;
			enablePrompts = true;
			gType = 92; //After shuffling card ranks are hidden from view 
		}
		else if ("animated".equals(input)||"a".equals(input)) { //Runs the game with animation.
			enableAnimation = true;
			enablePrompts = true;
			gType = 91; //After shuffling the cards are replaced with 🂠
		}
		else if ("fast".equals(input)||"f".equals(input)) { //Runs the game automatically without animation
			enableAnimation = false;									//and prompts disabled.
			enablePrompts = false;
			gType = 90; //The contents of the deck will be fully displayed
		}
		
		loadingEffect("Loading...‎0███████████████████100%", 60); //Simulates a loading bar
		pause(10);
		System.out.println();
		
		loadingEffect("Welcome to the game of WAR!\n", 50);
		
		loadingEffect("Creating a new digital deck.....", 50);
		Deck d = new Deck(); //Create a new Deck object <d>
		pause(20);
		d.displayDeck(90); //Display the newly created deck
		System.out.println();

		loadingEffect("Shuffling the deck.....", 50);
		d.shuffle(); //Randomly shuffle the cards in Deck <d>
		pause(20);
		d.displayDeck(gType); //Display the newly shuffled deck
		System.out.println();
		
		System.out.println("Deck setup complete.");
		pause(20);
		
		while (!d.isEmpty()) {
			loadingEffect("\t♢♠♢♠♢♠♢♠ROUND ONE♠♢♠♢♠♢♠♢\n", 40);
			round = 1; //While in first round, set <round> to 1
			loadingEffect("\tUser, please press <enter> to pick a card...", 50);
			promptEnterKey();
			Card a = d.draw(); //Draw first card
			loadingEffect(d.getSuits(), 100);
			loadingEffect("USER: [" + a.getRank() + a.getSuit() + "]\n", 100);
			pause(300);
			loadingEffect("\tNow the COMPUTER will draw a card.", 50);
			Card b = d.draw(); //Draw second card
			loadingEffect(d.getSuits(), 100);
			loadingEffect("COMP: [" + b.getRank() + b.getSuit() + "]\n", 100);
			pause(300);
			if (!cardCompare(a, b) && !d.isEmpty()) { //Compare cards. If !=, award round points to winner, otherwise continue
				
				loadingEffect("\t♣♥♣♥♣♥♣ROUND TWO♣♥♣♥♣♥♣\n", 40);
				round = 2; //While in second round, set <round> to 2
				loadingEffect("\tUser, please press <enter> to pick a card...", 50);
				promptEnterKey();
				a = d.draw(); //Draw first card
				loadingEffect(d.getSuits(), 100);
				loadingEffect("USER: [" + a.getRank() + a.getSuit() + "]\n", 100);
				pause(300);
				loadingEffect("\tNow the COMPUTER will draw a card.", 50);
				b = d.draw(); //Draw second card
				loadingEffect(d.getSuits(), 100);
				loadingEffect("COMP: [" + b.getRank() + b.getSuit() + "]\n", 100);
				pause(300);
				if (!cardCompare(a, b) && !d.isEmpty()) { //Compare cards. If !=, award round points to winner, otherwise continue
					
					loadingEffect("\t♢♥♢♥♢♥ROUND THREE♥♢♥♢♥♢\n", 40);
					round = 3; //While in third round, set <round> to 3
					loadingEffect("\tUser, please press <enter> to pick a card...", 50);
					promptEnterKey();
					a = d.draw(); //Draw first card
					loadingEffect(d.getSuits(), 100);
					loadingEffect("USER: [" + a.getRank() + a.getSuit() + "]\n", 100);
					pause(300);
					loadingEffect("\tNow the COMPUTER will draw a card.", 50);
					b = d.draw(); //Draw second card
					loadingEffect(d.getSuits(), 100);
					loadingEffect("COMP: [" + b.getRank() + b.getSuit() + "]\n", 100);
					pause(300);
					cardCompare(a, b);
					three = true;
				}
			}
				
				
			
		}

		pause(400);
		System.out.print("!DECK EMPTY!\n\n"); //Inform the user when the loop breaks
		pause(800);
		System.out.println("USER Points: " + pAPoints); //Display final score
		System.out.println("COMPUTER Points: " + pBPoints);
		if (pAPoints > pBPoints) 
			System.out.println("USER WINS!!!");
		else if (pAPoints < pBPoints) 
			System.out.println("COMPUTER WINS!!!");
		else if (pAPoints == pBPoints)
			System.out.println("TIE GAME!!!");
				
		keyboard.close(); //Close the Scanner object
	}
	
//-----------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------------------------------------------------------------------------//
	
	public static boolean cardCompare (Card a, Card b) { //A method for comparing the ranks of 2 cards
		int numCards = (round*2);
		if (a.getRank() > b.getRank()) { //If Card A is higher than Card B
			awardPoints(numCards, 0); //Player A is awarded the current round's points
			loadingEffect("USER Wins!!! + " + numCards + " card(s)"  //inform the players who won
					+ "\t\tSCORE:\n" //Display current scores
					+ "\t\t\t\t\tUSER: " + pAPoints + "\n" 
					+ "\t\t\t\t\tCOMPUTER: " + pBPoints + "\n", 50);
			return true; //The method returns TRUE
		}
		else if (a.getRank() < b.getRank()) { //If Card A is lower than Card B
			awardPoints(0, numCards); //Player B is awarded the current round's points
			loadingEffect("COMPUTER Wins!!! + " + numCards + " card(s)"  //inform the players who won
					+ "\t\tSCORE:\n" //Display current scores
					+ "\t\t\t\t\tUSER: " + pAPoints + "\n"
					+ "\t\t\t\t\tCOMPUTER: " + pBPoints + "\n", 50);
			return true; //The method returns TRUE
		}
		else if (a.getRank() == b.getRank()) { //If the ranks are equal
			System.out.println("!STALEMATE! No points awarded."); //Inform the players
		}
	return false; //The method returns FALSE
	}
	
	public static void awardPoints (int a, int b) { //Small method for awarding points
		pAPoints += a;
		pBPoints += b;
	}
	
	public static void promptEnterKey() { //Prompt method provided by Professor Case.
	if (enablePrompts) { //Will only run if prompts are enabled
		
			try 
			{
				System.in.read(new byte[2]);
			}
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
	public static void pause(int t) { //A method to pause the thread for <t> time.
		if (enableAnimation) //Will only run if animations are enabled
		try {
			Thread.sleep(t); //1000ms = 1s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void loadingEffect(String S, int t) { //Outputs the contents of any string one character
		for (int i = 0; i < S.length(); i++) { 					  //at a time with a pause() in between
			System.out.print(S.charAt(i));
			pause(t);
		}
		System.out.println(); //Includes a println() for convenience
	}
	
	

	

}
