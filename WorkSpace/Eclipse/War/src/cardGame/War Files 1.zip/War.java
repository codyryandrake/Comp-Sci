/*
 * Name: Cody Ryan
 * Date: 
 * Description: The War class handles 
 * Sources Cited: <list any books, web pages, and people who helped you complete the homework>
 */

package cardGame;

import java.io.IOException;


public class War 
{
	public static void main(String[] args) throws IOException
	{
		int playerAPoints = 0;
		int playerBPoints = 0;
		int round = 1;
		
		System.out.println("Welcome to the game of WAR! Press <enter> to play...");
		promptEnterKey();
		
		System.out.print("Creating a new digital deck");
		//loadingEffect();
		Deck d = new Deck();
		System.out.println("Deck successfully created!\n");
		//pause(1);
		d.displayDeck();
		System.out.println();

		System.out.print("Shuffling the deck");
		//loadingEffect();
		d.shuffle();
		System.out.println("Deck successfully shuffled!\n");
		//pause(1);
		d.displayDeck();
		System.out.println();
		
		System.out.println("Deck setup complete. Press <enter> to draw a card...\n");
		promptEnterKey();
		
		while (!d.isEmpty())
		{
			round = 1;
			System.out.println("ROUND " + round);
			System.out.println("Draw card?");
			promptEnterKey();
			Card a = d.draw();
			System.out.print("Card A: (" + a.getRank() + a.getSuit() + ")\n");
			Card b = d.draw();
			System.out.print("Card B: (" + b.getRank() + b.getSuit() + ")\n");
			
			if (a.getRank() >= b.getRank())
			{
				if (a.getRank() == b.getRank())
				{
					round = 2;
					System.out.println("!STALEMATE!");
					System.out.println("	ROUND " + round);
					System.out.println("Draw card?");
					promptEnterKey();
					a = d.draw();
					System.out.print("	Card A: (" + a.getRank() + a.getSuit() + ")\n");
					b = d.draw();
					System.out.print("	Card B: (" + b.getRank() + b.getSuit() + ")\n");
					
					if (a.getRank() >= b.getRank())
					{
						if (a.getRank() == b.getRank())
						{
							round = 3;
							System.out.println("!STALEMATE!");
							System.out.println("		ROUND " + round);
							System.out.println("Draw card?");
							promptEnterKey();
							a = d.draw();
							System.out.print("		Card A: (" + a.getRank() + a.getSuit() + ")\n");
							b = d.draw();
							System.out.print("		Card B: (" + b.getRank() + b.getSuit() + ")\n");
							if (a.getRank() >= b.getRank())
							{
								if (a.getRank() == b.getRank())
								{
									playerAPoints += 0;
									playerBPoints += 0;
									pause(1);
									System.out.println("Stalemate! No points awarded.");
									System.out.println();
									pause(1);
								}
								else
								{
									playerAPoints += 3;
									pause(1);
									System.out.println("Player A Wins! Awarded 3 points.");
									System.out.println();
									pause(1);
								}
							}
							else
							{
								playerBPoints += 3;
								pause(1);
								System.out.println("Player B Wins! Awarded 3 points.");
								System.out.println();
								pause(1);
							}
						}
						else
						{
							playerAPoints += 2;
							pause(1);
							System.out.println("Player A Wins! Awarded 2 points.");
							System.out.println();
							pause(1);
						}
					}
					else
					{
						playerBPoints += 2;
						pause(1);
						System.out.println("Player B Wins! Awarded 2 points.");
						System.out.println();
						pause(1);
					}
				}
				else
				{
					playerAPoints += 1;
					pause(1);
					System.out.println("Player A Wins! Awarded 1 points.");
					System.out.println();
					pause(1);
				}
			}
			else
			{
				playerBPoints += 1;
				pause(1);
				System.out.println("Player B Wins! Awarded 1 points.");
				System.out.println();
				pause(1);
			}
		}
		
		pause(1);
		System.out.println("Player A Points: " + playerAPoints);
		System.out.println("Player B Points: " + playerBPoints);
		
		
	}
	
	public static void promptEnterKey()
	{
		try 
		{
			System.in.read(new byte[2]);
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void loadingEffect()
	{
		for (int i = 0; i < 3; i++)
		{
			pause(1);
			System.out.print(".");
		}
		pause(2);
		System.out.println();
	}
	
	public static void pause(int t)
	{
		try {
			Thread.sleep(t*1000); //1000ms = 1s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	

}
