/*
 * Name: Cody Ryan
 * Date: 
 * Description: The Deck class handles creating a new deck, returning cards in the deck
 * 				and shuffling the deck upon command.
 * Sources Cited: <list any books, web pages, and people who helped you complete the homework>
 */


package cardGame;

import java.util.Random;

public class Deck {
	private Card[] deck = new Card[52]; //Initialize a new array (length 52) of <Card> objects.
	private int top = 0; //<top> serve as the marker for the top of the <deck[0]> array.
	private char[] S = {'C', 'D', 'S', 'H'}; //Fill the char array <S[]> with the possible suits.
	private Random rand = new Random(); //Generate a new random object <rand> for future use.

	
	
	public Deck() //Construct the deck
	{
		for (int s = 0; s < S.length; s++) //The outer loop will increment		
		{								   //through the S[{C,D,H,S}] array.
			for (int r = 2; r < 15; r++) //The inner loop will increment through the possible ranks,
			{							 //{2, 3, 4, 5, 6, 7, 8, 9, 10, 11(J), 12(Q), 13(K), 14(A)}
				deck[top] = new Card(r, S[s]);//Every new Card object is assigned the current 
											  //rank and suit.
				top++; //Use <top> to cycle through the deck array.
			}
			System.out.println();
		}
		top = -1; //Reset <top> to -1 in preparation for the first card draw of a new deck.
	}
	
	public void shuffle() //Refresh the deck by rearranging the cards randomly 
	{					  //and reseting the top of the deck.
		for (int c = 0; c < deck.length; c++) //Loop through every card in the deck.
		{
			swap(c, rand.nextInt(deck.length)); //Swap the current card with another random
		}										//card from the deck.
		top = -1; //Reset <top> to -1 in preparation for the first card draw of a new deck.
	}
	
	public Card draw() //Return the next top card.
	{
		top++;
		return deck[top];
	}
	
	public boolean isEmpty()
	{
		if (top == deck.length-1) //If all the cards have been drawn,
		{
			System.out.println("!DECK EMPTY!");
			return true; //the deck is empty.
		}
		
		return false; //Otherwise the deck isn't empty!

	}
	
	private void swap(int i, int j)
	{
		Card temp = deck[i]; //Create a place-holder card <temp> and copy deck[i] to it.
		deck[i] = deck[j]; //Copy deck[j] to deck[i];
		deck[j] = temp; //Copy the <temp> card (a copy of deck[i]) to deck[j] 
	}
	
	public void displayDeck()
	{
		int count = 0;
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 13; j++)
			{
				System.out.print("(" + deck[count].getRank() + deck[count].getSuit() + ")");
				count++;
			}
			System.out.println();
		}
	}
	

	
}