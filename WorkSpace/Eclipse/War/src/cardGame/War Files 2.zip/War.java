/*
 * Name: Cody Ryan
 * Date: 
 * Description: The War class handles 
 * Sources Cited: <list any books, web pages, and people who helped you complete the homework>
 */

package cardGame;

import java.io.IOException;
import java.util.Random;

public class War 
{
	static int pAPoints = 0; //Scorekeeper variable for 
	static int pBPoints = 0;
	static int round = 1; //The round always starts as one.
	static boolean enable = true; //boolean control for pause() method.
	static boolean three = false; //third round detector.
	static Random rand = new Random();
	
	public static void main(String[] args) throws Exception
	{
		loadingEffect("Loading...‎0███████████████████100%", 60);
		pause(10, enable);
		System.out.println();
		loadingEffect("Welcome to the game of WAR! Press <enter> to play.\n", 50);
		//promptEnterKey();
		
		loadingEffect("Creating a new digital deck.....", 50);
		Deck d = new Deck();
		pause(20, enable);
		d.displayDeck(90);
		System.out.println();

		loadingEffect("Shuffling the deck.....", 50);
		d.shuffle();
		pause(20, enable);
		d.displayDeck(92);
		System.out.println();
		
		System.out.println("Deck setup complete.");
		pause(20, enable);
		
		while (!d.isEmpty()) {
			loadingEffect("\t♢♠♢♠♢♠♢♠ROUND ONE♠♢♠♢♠♢♠♢", 40);
			round = 1; //While in first round, set <round> to 1
			loadingEffect("\tUser, please press <enter> to pick a card...", 50);
			//promptEnterKey();
			Card a = d.draw(); //Draw first card
			loadingEffect(d.getSuits(), 100);
			loadingEffect("USER: [" + a.getRank() + a.getSuit() + "]\n", 100);
			pause(300, enable);
			loadingEffect("\tNow the COMPUTER will draw a card.", 50);
			Card b = d.draw(); //Draw second card
			loadingEffect(d.getSuits(), 100);
			loadingEffect("COMP: [" + b.getRank() + b.getSuit() + "]\n", 100);
			pause(300, enable);
			if (!cardCompare(a, b) && !d.isEmpty()) { //Compare cards. If !=, award round points to winner, otherwise continue
				
				loadingEffect("\t♣♥♣♥♣♥♣ROUND TWO♣♥♣♥♣♥♣", 40);
				round = 2; //While in second round, set <round> to 2
				loadingEffect("\tUser, please press <enter> to pick a card...", 50);
				//promptEnterKey();
				a = d.draw(); //Draw first card
				loadingEffect(d.getSuits(), 100);
				loadingEffect("USER: [" + a.getRank() + a.getSuit() + "]\n", 100);
				pause(300, enable);
				loadingEffect("\tNow the COMPUTER will draw a card.", 50);
				b = d.draw(); //Draw second card
				loadingEffect(d.getSuits(), 100);
				loadingEffect("COMP: [" + b.getRank() + b.getSuit() + "]\n", 100);
				pause(300, enable);
				if (!cardCompare(a, b) && !d.isEmpty()) { //Compare cards. If !=, award round points to winner, otherwise continue
					
					loadingEffect("\t♢♥♢♥♢♥ROUND THREE♥♢♥♢♥♢", 40);
					round = 3; //While in third round, set <round> to 3
					loadingEffect("\tUser, please press <enter> to pick a card...", 50);
					//promptEnterKey();
					a = d.draw(); //Draw first card
					loadingEffect(d.getSuits(), 100);
					loadingEffect("USER: [" + a.getRank() + a.getSuit() + "]\n", 100);
					pause(300, enable);
					loadingEffect("\tNow the COMPUTER will draw a card.", 50);
					b = d.draw(); //Draw second card
					loadingEffect(d.getSuits(), 100);
					loadingEffect("COMP: [" + b.getRank() + b.getSuit() + "]\n", 100);
					pause(300, enable);
					cardCompare(a, b);
					three = true;
				}
			}
				
				
			
		}
			//System.out.println("--------------------------------");

		pause(400, enable);
		System.out.print("!DECK EMPTY!\n\n");
		pause(800, enable);
		System.out.println("USER Points: " + pAPoints);
		System.out.println("COMPUTER Points: " + pBPoints);
		if (three) {
			System.out.println("ROUND 3 OCCURRED");
		}
	}
	
//-----------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------------------------------------------------------------------------//
//-----------------------------------------------------------------------------------------------------------------------------//
	
	public static boolean cardCompare (Card a, Card b) {
	if (a.getRank() > b.getRank()) {
			awardPoints(round, 0);
			loadingEffect("USER Wins!!! + " + round + "\t\t\tSCORE:\n"
					+ "\t\t\t\t\tUSER: " + pAPoints + "\n"
					+ "\t\t\t\t\tCOMPUTER: " + pBPoints + "\n", 50);
			return true;
		}
		else if (a.getRank() < b.getRank()) {
			awardPoints(0, round);
			loadingEffect("COMPUTER Wins!!! + " + round + "\t\t\tSCORE:\n"
					+ "\t\t\t\t\tUSER: " + pAPoints + "\n"
					+ "\t\t\t\t\tCOMPUTER: " + pBPoints + "\n", 50);
			return true;
		}
		else if (a.getRank() == b.getRank()) {
			System.out.println("!STALEMATE! No points awarded.");
		}
	//System.out.println("FALSE");
	return false;
	}
	
	public static void awardPoints (int a, int b) {
		pAPoints += a;
		pBPoints += b;
	}
	
	public static void promptEnterKey() //TO-DO: Change from <enter> to mouse click.
	{
		try 
		{
			System.in.read(new byte[2]);
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	
	public static void pause(int t, boolean enable) {
		if (enable)
		try {
			Thread.sleep(t); //1000ms = 1s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void loadingEffect(String S, int t) {
		for (int i = 0; i < S.length(); i++) {
			System.out.print(S.charAt(i));
			pause(t, enable);
		}
		System.out.println();
	}
	
	

	

}
