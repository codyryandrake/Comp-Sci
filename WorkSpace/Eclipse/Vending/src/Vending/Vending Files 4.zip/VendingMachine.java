/*
Name: Cody Ryan
Date: 10.23.18
Description: This class handles the mechanical working of a vending machine including inventory, transactions, and sales reporting.
Sources Cited: <Class slides>
*/
package Vending;

public class VendingMachine implements VendingMachineInterface {
	private String[] snackNames = {"null", "Snickers", "Twix", "Reeses"}; //null bars are my favorite!
	private int[] Cost = {0, 100, 115, 130}; //Cost of each candy bar
	private int[] Inventory = new int[snackNames.length]; //Inventory container for null and n snacks.
	private int Selection; 
	private int cDeposit; //The temp var for holding cents during transactions
	private int Profits; //Accumulating profits
	private static boolean enableAnimation = false; //Animation control. Set to <false> for JUnit testing.
	

	public VendingMachine(int s, int t, int r) { //Custom constructor
		setInventory(1, s); //Initialize inventory
		setInventory(2, t);
		setInventory(3, r);
		setSelection(0); //Initialize other vars
		setDeposit(0);
		setProfits(0);
	}
	

	/*
	 * Setter and getter methods
	 */

	
	private void setInventory (int selection, int quantity) {
		Inventory[selection] = quantity;
	}
	
	
	private void setSelection(int sel) {
		Selection = sel;
	}
	
	private void setProfits(int p) {
		Profits = p;
	}

	private void setDeposit(int d) {
		cDeposit = d;
	}
	

	
	
	@Override
	public void insertCents(int c) {
		cDeposit = c; //Immediately store cents in <cDeposit>
		loadingEffect("You deposit " + cDeposit + " cents into the machine.", 40);
		if (cDeposit%5 != 0) { //If the remainder of c over 5 is not 0
			loadingEffect("Sorry, this machine only accepts change in multiples of 5.", 40);
			returnUnspentCents(); //Return change to user
			throw new ImproperCoinsException(); //Throw an exception
		}
	}

	@Override
	public void makeSelection(int s) {
		if (0 < s && s < Inventory.length) { //If <s> is a valid selection between 1 and the nth selection
			loadingEffect("\n\t\t\t\t\t*" + snackNames[s] + " button pressed*\n\n", 40);
			if (Inventory[s] > 0) { //If the selected item is in stock
				setSelection(s); //Set selection choice
			}
			else { //If the item is sold out
				loadingEffect("Sorry, " + snackNames[s] +" is currently sold out.", 40); 
				throw new ImproperSelectionException(snackNames[s]); //throw an exception
			}
		}
		else { //If the selection is invalid
			loadingEffect("\n\t\t\t\t\t*unlit button pressed*\n\n"
					+ "Selection invalid. Valid selections: ", 40); 
			displayInventory();
			throw new ImproperSelectionException(); //throw an exception
		}
		
	}

	@Override
	public int purchaseSelection() { 
		loadingEffect("\n\t\t\t\t\t*purchase button pressed*\n\n", 40);
		if (Selection != 0) { //If <Selection> was updated in makeSelection()
			if (cDeposit >= Cost[Selection]) { //If the current deposit amount is at least the cost of the selection
				cDeposit = cDeposit-Cost[Selection]; //Subtract the cost of the selection from the deposit amount
				Inventory[Selection] -= 1; //Remove a single unit of the selection from inventory
				loadingEffect("A " + snackNames[Selection] + " candy bar falls to the retrieval slot.", 40);
				Profits += Cost[Selection]; //Increase profits by the amount of the selection's cost
				setSelection(0); //Reset <Selection> after a successful purchase
				return returnUnspentCents(); //Finally return the unspent remainder to the user
			}
			else { //If the cost of the selection exceeds the current deposit amount
				loadingEffect("Insufficient funds to purchase a " + snackNames[Selection] + " candy bar.", 40);
				int remainder = Cost[Selection] - cDeposit; //The remaining cost is the cost of the selection minus the current deposit
				throw new ImproperPurchaseException(remainder); //Throw exception with determined remainder
			}
		}
		else //makeSelection() was not called first
		{
			loadingEffect("Please make a selection before attempting to purchase an item.", 40);
			throw new ImproperPurchaseException(); //makeSelection() has not been called
		}

	}

	@Override
	public int returnUnspentCents() { //Returns the remaining change in the machine to the user
		int unspentCents = cDeposit; //Transfer remaining <cDeposit> value to <unspentCents>
		cDeposit = 0; //So we can reset cDeposit
		loadingEffect("\n\t\t\t\t\t*coin return pressed*\n\n", 40);
		if (unspentCents > 0) { //If there is change to return
				loadingEffect("You hear your change fall into the return slot.\n"
				+ "\t\t\t\t\tReturned: " + unspentCents + " cents.", 40); 
		}
		else
			loadingEffect("\t\t\t\t\tCoin deposit empty.\n", 40);
		
		return unspentCents; //And finally return our <unspentCents>
	}

	@Override
	public int getProfits() { //Returns accumulated profit
		loadingEffect("Current iVend profit:" + Profits + " cents.", 40);
		return Profits;
	}
	
	public void displayInventory() {
		for (int i = 1; i < Inventory.length; i++)
				loadingEffect("\t\t\t[" + i + "] " +  snackNames[i] + ":" + Inventory[i] + "\n", 40);
	}
	
	private static void pause(int time) { //A method to pause the thread for <t> time.
		if (enableAnimation) //Will only run if animations are enabled
		try {
			Thread.sleep(time); //1000ms = 1s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	private static void loadingEffect(String string, int time) { //Method for animating strings
		for (int i = 0; i < string.length(); i++) { 					 
			System.out.print(string.charAt(i)); //Outputs the contents of any string one character at a time 
			pause(time); 	 								   //with a pause() in between
		}
		System.out.println(); //Includes a println() for convenience
	}


}
