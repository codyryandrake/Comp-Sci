/*
Name: Cody Ryan
Date: 10.23.18
Description: This class handles the mechanical working of a vending machine including inventory, transactions, and sales reporting.
Sources Cited: <Class slides>
*/
package Vending;

public class VendingMachine implements VendingMachineInterface {
	private int[] Inventory = new int[4]; //Inventory container for null and 3 snacks.
	private String[] snackNames = {"null", "Snickers", "Twix", "Reeses"}; //null bars are my favorite!
	private int costSnickers = 100; //Cost of each candy bar
	private int costTwix = 115;
	private int costReeses = 130;
	private int[] Cost = {0, costSnickers, costTwix, costReeses};
	private int cDeposit = 0; //The temp var for holding cents during transactions
	private int Selection = 0; 
	private int Profits =0; //Accumulating profits
	
	public VendingMachine() { //Default contructor
		setNumSnickers(5); //Default inventory
		setNumTwix(7);
		setNumReeses(4);
	}
	
	public VendingMachine(int s, int t, int r) { //Custom constructor
		setNumSnickers(s); //Custom inventory
		setNumTwix(t);
		setNumReeses(r);
	}
	
	/*
	 * Setter and getter methods
	 */
	public void setNumSnickers (int s) {
		Inventory[1] = s;
	}
	
	public void setNumTwix (int t) {
		Inventory[2] = t;
	}
	
	public void setNumReeses (int r) {
		Inventory[3] = r;
	}
	
	public void setSelection(int sel) {
		Selection = sel;
	}
	
	public int getNumSnickers () {
		return Inventory[1];
	}
	
	public int getNumTwix () {
		return Inventory[2];
	}
	
	public int getNumReeses () {
		return Inventory[3];
	}
	
	public int getDeposit() {
		return cDeposit;
	}
	
	public int getCost(int Selection) {
		return Cost[Selection];
	}
	
	public int getSelection() {
		return Selection;
	}
	

	@Override
	public void insertCents(int c) {
		cDeposit = c; //Immediately store cents in <cDeposit>
		System.out.println("You deposit " + cDeposit + " cents into the machine.");
		if (!(c%5==0)) { //If the remainder of c over 5 is not 0
			System.out.println("Sorry, this machine only accepts change in multiples of 5.\n");
			returnUnspentCents(); //Return change to user
			throw new ImproperCoinsException(); //Throw an exception
		}
	}

	@Override
	public void makeSelection(int s) {
		if (s == 1 || s == 2 || s == 3) { //If <s> is a valid selection
			if (Inventory[s] > 0) { //If the selected item is in inventory
				setSelection(s); //Set selection choice
			}
			else { //If the item is sold out
				System.out.println("Sorry, " + snackNames[s] +" is currently sold out."); 
				throw new ImproperSelectionException(snackNames[s]); //throw an exception
			}
		}
		else { //If the selection is invalid
			System.out.println("The selection you have made does not exist."); 
			throw new ImproperSelectionException(); //throw an exception
		}
		
	}

	@Override
	public int purchaseSelection() { 
		if (Selection != 0) { //If <Selection> was updated in makeSelection()
			if (cDeposit >= Cost[Selection]) { //If the current deposit amount exceeds the cost of the selection
				cDeposit = cDeposit-Cost[Selection]; //Subtract the cost of the selection from the deposit amount
				Inventory[Selection] -= 1; //Remove a single unit of the selection from inventory
				Profits += Cost[Selection]; //Increase profits by the amount of the selection
				System.out.println("A " + snackNames[Selection] + " candy bar falls to the retrieval slot.");
				return Inventory[Selection]; //TODO This return info is currently unused
			}
			else { //If the cost of the selection exceeds the current deposit amount
				System.out.println("Insufficient funds to purchase a " + snackNames[Selection] + " candy bar.");
				int remainder = Cost[Selection] - cDeposit; //The remaining cost is the cost of the selection minus the current deposit
				throw new ImproperPurchaseException(remainder); //Not enough money inserted
			}
		}
		else
		{
			System.out.println("Please make a selection before attempting to purchase an item.");
			throw new ImproperPurchaseException(); //makeSelection() has not been called
		}

	}

	@Override
	public int returnUnspentCents() { //Returns any unspent change to the user
		System.out.println("You hear your change fall into the return slot.\n"
				+ "Returned: " + cDeposit + " cents."); 
		return cDeposit;
	}

	@Override
	public int getProfits() { //Returns accumulated profit
		System.out.println("Current iVend profit:" + Profits);
		return Profits;
	}
	
	public void display() {
		System.out.println("Inventory:");
		for (int i = 1; i < 4; i++)
				System.out.print("\t" + snackNames[i] + ":" + Inventory[i] + "\n");
	}
	


}
