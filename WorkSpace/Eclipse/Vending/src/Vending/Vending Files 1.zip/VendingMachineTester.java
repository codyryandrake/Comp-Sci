/*
Name: Cody Ryan
Date: 10.23.18
Description: This JUnit tester tests all VendingMachine methods.
Sources Cited: <Class slides>
*/

package Vending;
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class VendingMachineTester {
	
	
	@Test(expected = ImproperCoinsException.class) //TEST 1
	public void ImproperCoinsExceptionTest() {
		System.out.println("TEST 1\n");
		VendingMachine iVend = new VendingMachine();
		iVend.insertCents(12); //Try depositing a non-multiple of 5 into the machine
	}
	
	@Test(expected = ImproperSelectionException.class) //TEST 2
	public void ImproperSelectionExceptionTest1() {
		System.out.println("TEST 2\n");
		VendingMachine iVend = new VendingMachine();
		iVend.makeSelection(4); //Try to make an invalid selection
	}
	
	@Test(expected = ImproperSelectionException.class) //TEST 3
	public void ImproperSelectionExceptionTest2() {
		System.out.println("TEST 3\n");
		VendingMachine iVend = new VendingMachine(3, 0, 5);
		iVend.makeSelection(2); //Try to select an out-of-stock item
	}
	
	@Test(expected = ImproperPurchaseException.class) //TEST 4
	public void ImproperPurchaseExceptionTest1() {
		System.out.println("TEST 4\n");
		VendingMachine iVend = new VendingMachine();
		iVend.purchaseSelection(); //Try to purchase before making a selection
	}
	
	@Test(expected = ImproperPurchaseException.class) //TEST 5
	public void ImproperPurchaseException2() {
		System.out.println("TEST 5\n");
		VendingMachine iVend = new VendingMachine();
		iVend.makeSelection(2); //Select Twix
		iVend.purchaseSelection(); //Try to purchase Twix before depositing any change
	}
	
	@Test //TEST 6
	public void changeReturnTest1() {
		System.out.println("TEST 6\n");
		VendingMachine iVend = new VendingMachine();
		iVend.insertCents(200); //Deposit 200 cents into the machine
		iVend.makeSelection(1); //Snickers costs 100 cents
		iVend.purchaseSelection(); //Purchase 1 Snickers candy bar and deduct the cost from the current deposit
		assertEquals(100, iVend.returnUnspentCents()); //Original deposit of 200 minus cost of Snickers (100) should return 100 cents
	}
	
	@Test //TEST 7
	public void changeReturnTest2() {
		System.out.println("TEST 7\n");
		VendingMachine iVend = new VendingMachine();
		iVend.insertCents(150); //Original deposit of 150 cents
		assertEquals(150, iVend.returnUnspentCents()); //Original deposit should be equal to returned amount if no purchase was made.
	}
	
	@Test //TEST 8
	public void getProfitsTest() {
		System.out.println("TEST 8\n");
		VendingMachine iVend = new VendingMachine();
		iVend.insertCents(1000); //Original deposit of 1000 cents
		
		iVend.makeSelection(1); //Select Snickers
		iVend.purchaseSelection(); //Purchase Snickers for 100 cents
		
		iVend.makeSelection(2); //Select Twix
		iVend.purchaseSelection(); //Purchase Twix for 115 cents
		
		iVend.makeSelection(3); //Select Reeses
		iVend.purchaseSelection(); //Purchase Reeses for 130 cents
		
		assertEquals(345, iVend.getProfits()); //Profit should equal 345 cents
	}
	
	

}
