/*
Name: Cody Ryan
Date: 10.23.18
Description: This class handles the mechanical working of a vending machine including inventory, transactions, and sales reporting.
Sources Cited: <Class slides>
*/
package Vending;

public class VendingMachine implements VendingMachineInterface {
	private int[] Inventory = new int[4]; //Inventory container for null and 3 snacks.
	private String[] snackNames = {"null", "Snickers", "Twix", "Reeses"}; //null bars are my favorite!
	private int[] Cost = {0, 100, 115, 130}; //Cost of each candy bar
	private int cDeposit = 0; //The temp var for holding cents during transactions
	private int Selection = 0; 
	private int Profits = 0; //Accumulating profits
	private static boolean enableAnimation = false;
	
	public VendingMachine() { //Default contructor
		setNumSnickers(5); //Default inventory
		setNumTwix(7);
		setNumReeses(4);
	}
	
	public VendingMachine(int s, int t, int r) { //Custom constructor
		setNumSnickers(s); //Custom inventory
		setNumTwix(t);
		setNumReeses(r);
	}
	
	/*
	 * Setter and getter methods
	 */
	public void setNumSnickers (int s) {
		Inventory[1] = s;
	}
	
	public void setNumTwix (int t) {
		Inventory[2] = t;
	}
	
	public void setNumReeses (int r) {
		Inventory[3] = r;
	}
	
	public void setSelection(int sel) {
		Selection = sel;
	}
	
	public int getNumSnickers () {
		return Inventory[1];
	}
	
	public int getNumTwix () {
		return Inventory[2];
	}
	
	public int getNumReeses () {
		return Inventory[3];
	}
	
	public int getDeposit() {
		return cDeposit;
	}
	
	public int getCost(int Selection) {
		return Cost[Selection];
	}
	
	public int getSelection() {
		return Selection;
	}
	

	@Override
	public void insertCents(int c) {
		cDeposit = c; //Immediately store cents in <cDeposit>
		loadingEffect("You deposit " + cDeposit + " cents into the machine.", 40);
		if (!(c%5==0)) { //If the remainder of c over 5 is not 0
			loadingEffect("Sorry, this machine only accepts change in multiples of 5.", 40);
			returnUnspentCents(); //Return change to user
			throw new ImproperCoinsException(); //Throw an exception
		}
	}

	@Override
	public void makeSelection(int s) {
		if (s == 1 || s == 2 || s == 3) { //If <s> is a valid selection
			if (Inventory[s] > 0) { //If the selected item is in stock
				setSelection(s); //Set selection choice
				loadingEffect("\n\t\t\t\t\t*" + snackNames[s] + " button pressed*\n\n", 40);
			}
			else { //If the item is sold out
				loadingEffect("\n\t\t\t\t\t*" + snackNames[s] + " button pressed*\n\n"
						+ "Sorry, " + snackNames[s] +" is currently sold out.", 40); 
				throw new ImproperSelectionException(snackNames[s]); //throw an exception
			}
		}
		else { //If the selection is invalid
			loadingEffect("\n\t\t\t\t\t*unlit button pressed*\n\n"
					+ "Selection invalid. Valid selections: ", 40); 
			for (int i = 1; i < snackNames.length; i++) { //Use a for-loop
				loadingEffect("\t\t\t\t\t" + snackNames[i] + " \n", 40); //to iterate through the elements of <snackNames[]>
			}
			throw new ImproperSelectionException(); //throw an exception
		}
		
	}

	@Override
	public int purchaseSelection() { 
		loadingEffect("\n\t\t\t\t\t*purchase button pressed*\n\n", 40);
		if (Selection != 0) { //If <Selection> was updated in makeSelection()
			if (cDeposit >= Cost[Selection]) { //If the current deposit amount is at least the cost of the selection
				cDeposit = cDeposit-Cost[Selection]; //Subtract the cost of the selection from the deposit amount
				Inventory[Selection] -= 1; //Remove a single unit of the selection from inventory
				loadingEffect("A " + snackNames[Selection] + " candy bar falls to the retrieval slot.", 40);
				Profits += Cost[Selection]; //Increase profits by the amount of the selection's cost
				return returnUnspentCents(); //Finally return the unspent remainder to the user
			}
			else { //If the cost of the selection exceeds the current deposit amount
				loadingEffect("Insufficient funds to purchase a " + snackNames[Selection] + " candy bar.", 40);
				int remainder = Cost[Selection] - cDeposit; //The remaining cost is the cost of the selection minus the current deposit
				throw new ImproperPurchaseException(remainder); //Throw exception with determined remainder
			}
		}
		else //makeSelection() was not called first
		{
			loadingEffect("Please make a selection before attempting to purchase an item.", 40);
			throw new ImproperPurchaseException(); //makeSelection() has not been called
		}

	}

	@Override
	public int returnUnspentCents() { //Returns the remainder of <cDeposit> and resets it
		int unspentCents = cDeposit; //Transfer remaining <cDeposit> value to <unspentCents>
		cDeposit = 0; //So we can reset cDeposit
		loadingEffect("\n\t\t\t\t\t*coin return pressed*\n\n"
				+ "You hear your change fall into the return slot.\n"
				+ "\t\t\t\t\tReturned: " + unspentCents + " cents.", 40); 
		
		return unspentCents;
	}

	@Override
	public int getProfits() { //Returns accumulated profit
		loadingEffect("Current iVend profit:" + Profits + " cents.", 40);
		return Profits;
	}
	
	public void display() {
		loadingEffect("Inventory:", 40);
		for (int i = 1; i < Inventory.length; i++)
				loadingEffect("\t" + snackNames[i] + ":" + Inventory[i] + "\n", 40);
	}
	
	private static void pause(int time) { //A method to pause the thread for <t> time.
		if (enableAnimation) //Will only run if animations are enabled
		try {
			Thread.sleep(time); //1000ms = 1s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	private static void loadingEffect(String string, int time) { //Method for animating strings
		for (int i = 0; i < string.length(); i++) { 					 
			System.out.print(string.charAt(i)); //Outputs the contents of any string one character
			pause(time);  //at a time with a pause() in between
		}
		System.out.println(); //Includes a println() for convenience
	}
	


}
