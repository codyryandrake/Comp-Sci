/*
Name: Cody Ryan
Date: 10.31.18
Description: This class handles the mechanical working of a vending machine including inventory, transactions, and sales reporting.
Sources Cited: <Class slides>
*/
package Vending;

public class VendingMachine implements VendingMachineInterface {
	/**
	 * Private vars
	 * @param snackNames A String [] for holding snack descriptions. 
	 * @param cost An int [] for holding each snack's cost. 
	 * @param inventory An int [] for holding the quantity of each snack. Sized by the snackNames[]. 				    
	 * @param selection An int var for holding valid selection values.  		
	 * @param deposit An int var for holding non-negative change put into the machine.  		
	 * @param profits An int var for holding accumulating profits. 		    		    
	 */
	private String[] snackNames = {"Snickers", "Twix", "Reeses"};
	private int[] cost = {100, 115, 130};
	private int[] inventory = new int[snackNames.length]; 
	private int selection; 
	private int deposit;
	private int profits;
	private static boolean enableAnimation = false; 
	
/**
 * @param VendingMachine Allocate the designated number of each candy bar to the designated index within the 
 * @param inventory array.
 * @param selection initialized to -1 in preparation for a makeSelection() call.
 * @param deposit initialized to 0.
 * @param profits initialized to 0.
 */
	public VendingMachine(int s, int t, int r) { 
		setInventory(0, s); 
		setInventory(1, t);
		setInventory(2, r);
		setSelection(-1); 
		setDeposit(0);
		setProfits(0);
	}
	

//Private setter methods.
	
	private void setInventory (int selection, int quantity) {
		inventory[selection] = quantity;
	}
	
	
	private void setSelection(int sel) {
		selection = sel;
	}
	
	private void setProfits(int p) {
		profits = p;
	}

	private void setDeposit(int d) {
		deposit = d;
	}
	

	/**
	 * @param insertCents stores a valid value into 
	 * <deposit> and rejects invalid inserts.
	 * Exception: An ImproperCoinsException is thrown if c is a negative value.
	 * Exception: An ImproperCoinsException is thrown if c is not a multiple of 5.
	 */
	@Override
	public void insertCents(int c) {
		if (c < 0) {
			loadingEffect("Sorry, you cannot insert negative change into the machine.", 40);
			throw new ImproperCoinsException();
		}
		else { 
		deposit = c; 
		loadingEffect("You deposit " + deposit + " cents into the machine.", 40);
		if (deposit%5 != 0) { 
			loadingEffect("Sorry, this machine only accepts change in multiples of 5.", 40);
			returnUnspentCents(); 
			throw new ImproperCoinsException(); 
			}
		}	
	}

	

	/**
	 * @param makeSelection stores a valid value in the <selection> variable.
	 * Exception: An ImproperSelectionException is thrown if the value is outside the valid range.
	 * Exception: An ImproperSelectionException(String snack) is thrown if the selected snack is sold out.
	 */
	@Override
	public void makeSelection(int s) {
		if (-1 < s && s < inventory.length) { 
			loadingEffect("\n\t\t\t\t\t*" + snackNames[s] + " button pressed*\n\t\t\t\t\t", 40);
			if (inventory[s] > 0) { 
				loadingEffect("\nThe " + snackNames[s] + " button is glowing.", 40);
				setSelection(s);
			}
			else { 
				loadingEffect("Sorry, " + snackNames[s] +" is currently sold out.", 40); 
				setSelection(-1);
				throw new ImproperSelectionException(snackNames[s]); 
			}
		}
		else { 
			loadingEffect("\n\t\t\t\t\t*unmarked button pressed*\n\n"
					+ "Selection invalid. Valid selections: ", 40); 
			displayInventory();
			throw new ImproperSelectionException(); 
		}
		
	}

	/**
	 * @param purchaseSelection purchases the current selection:
	 * Removing the item from inventory and
	 * giving it to the customer. 
	 * Incrementing <profits> by the cost of the purchased item.
	 * Reseting <selection> to an invalid value of -1.
	 * Exception: The customer tries to purchase before selecting an item.
	 * Exception: The customer tries to purchase an item more costly than the <deposit> balance.
	 */
	@Override
	public int purchaseSelection() { 
		loadingEffect("\n\t\t\t\t\t*purchase button pressed*\n\n", 40);
		if (selection != -1) { 
			if (deposit >= cost[selection]) { 
				deposit = deposit-cost[selection]; 
				inventory[selection] -= 1; 
				loadingEffect("A " + snackNames[selection] + " candy bar falls to the retrieval slot.", 40);
				profits += cost[selection]; 
				loadingEffect("\nThe " + snackNames[selection] + " button is no longer glowing.", 40);
				setSelection(-1);
				return returnUnspentCents(); 
			}
			else { 
				loadingEffect("Insufficient funds to purchase a " + snackNames[selection] + " candy bar.", 40);
				int remainder = cost[selection] - deposit;
				throw new ImproperPurchaseException(remainder); 
			}
		}
		else 
		{
			loadingEffect("Please make a selection before attempting to purchase an item.", 40);
			throw new ImproperPurchaseException(); 
		}

	}

/** @param returnUnspentCents returns any available change to the customer upon request. */
	@Override
	public int returnUnspentCents() { 
		int unspentCents = deposit; 
		deposit = 0; 
		loadingEffect("\n\t\t\t\t\t*coin return pressed*\n\n", 40);
		if (unspentCents > 0) { 
				loadingEffect("You hear your change fall into the return slot.\n"
				+ "\t\t\t\t\tReturned: " + unspentCents + " cents.", 40); 
		}
		else
			loadingEffect("\t\t\t\t\tCoin deposit empty.\n", 40);
		return unspentCents; 
	}

	/** @param getProfits returns the current profits. */
	@Override
	public int getProfits() { 
		loadingEffect("Current iVend profit:" + profits + " cents.", 40);
		return profits;
	}
	
/** @param displayInventory displays each item in the inventory, it's cost and inventory count. */

	public void displayInventory() {
		for (int i = 0; i < inventory.length; i++)
				loadingEffect("\t\t\t[" + i + "] " +  snackNames[i] + ":\t $" + cost[i] + " cents (" + inventory[i] + ")\n", 40);
	}
	
	
/**
 * @param pause is a simple method for pausing the thread for a specified <time>.
 * @param time An int var for holding the specified time value.
 */
	private static void pause(int time) { 
		if (enableAnimation) 
		try {
			Thread.sleep(time); //1000ms = 1s
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @param loadingEffect outputs the characters of the passed <string> object
	 * with a pause(time) between each character. 
	 */
	private static void loadingEffect(String string, int time) { 
		for (int i = 0; i < string.length(); i++) { 					 
			System.out.print(string.charAt(i)); 
			pause(time); 	 								   
		}
		System.out.println(); 
	}


}
