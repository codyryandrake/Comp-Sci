package Vending;

public class iVend {

	public static void main(String[] args) {
		VendingMachine iVend = new VendingMachine();
		iVend.insertCents(200);
		iVend.makeSelection(1);
		iVend.purchaseSelection();
		iVend.purchaseSelection();
		iVend.getProfits();
		iVend.display();
		


	}

}
